#ifndef __DISPLAY_TEST_HPP__
#define __DISPLAY_TEST_HPP__

#include "display.hpp"
#include "easyDisplay.hpp"
#include "mediumDisplay.hpp"
#include "hardDisplay.hpp"
#include "gtest/gtest.h"

TEST(DisplayTest, CheckMissedPointsEasy){
    Display* test = new Easy();
    test->updateAnswer(true);
    EXPECT_EQ(test->checkPointsMissed(), 0);
    test->updateAnswer(false);
    EXPECT_EQ(test->checkPointsMissed(), 1);
    test->updateAnswer(false);
    test->updateAnswer(false);
    test->updateAnswer(false);
    test->updateAnswer(false);
    test->updateAnswer(false);
    EXPECT_EQ(test->checkPointsMissed(), 6);
}

TEST(DisplayTest, CheckMissedPointsMedium){
    Display* test = new Medium();
    test->updateAnswer(true);
    EXPECT_EQ(test->checkPointsMissed(), 0);
    test->updateAnswer(false);
    EXPECT_EQ(test->checkPointsMissed(), 1);
    test->updateAnswer(false);
    test->updateAnswer(false);
    test->updateAnswer(true);
    test->updateAnswer(false);
    EXPECT_EQ(test->checkPointsMissed(), 4);
}

TEST(DisplayTest, CheckMissedPointsHard){
    Display* test = new Hard();
    test->updateAnswer(true);
    EXPECT_EQ(test->checkPointsMissed(), 0);
    test->updateAnswer(false);
    EXPECT_EQ(test->checkPointsMissed(), 1);
    test->updateAnswer(true);
    test->updateAnswer(true);
    test->updateAnswer(false);
    EXPECT_EQ(test->checkPointsMissed(), 2);
}


#endif //__DISPLAY_TEST_HPP__

