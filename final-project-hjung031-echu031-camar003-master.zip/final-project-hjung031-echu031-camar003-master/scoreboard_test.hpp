#ifndef __SCOREBOARD_TEST_HPP__
#define __SCOREBOARD_TEST_HPP__

#include "gtest/gtest.h"

#include "scoreboard.hpp"

TEST(ScoreboardTest, ReturnCurrentScore) {
    scoreboard* test = new scoreboard(10);
    EXPECT_EQ(10, test->displayCurrentScore());
}

TEST(ScoreboardTest2, ReturnBestScore) {
    scoreboard* test = new scoreboard();
    test->calculateScore(true, true);
    test->calculateScore(false, true);
    EXPECT_EQ(20, test->displayBestScore());
}

TEST(ScoreboardTest3, CalculateScore1) {
    scoreboard* test = new scoreboard();
    test->calculateScore(true, true);
    test->calculateScore(false, true);
    test->calculateScore(false, true);
    test->calculateScore(false, true);
    test->calculateScore(false, true);
    test->calculateScore(false, true);
    EXPECT_EQ(60, test->displayBestScore());
}

TEST(ScoreboardTest3, CalculateScore2) {
    scoreboard* test = new scoreboard();
    test->calculateScore(true, true);
    test->calculateScore(false, false);
    test->calculateScore(false, true);
    test->calculateScore(false, false);
    test->calculateScore(false, false);
    test->calculateScore(false, true);
    EXPECT_EQ(30, test->displayBestScore());
}

#endif //__SCOREBOARD_TEST_HPP__
