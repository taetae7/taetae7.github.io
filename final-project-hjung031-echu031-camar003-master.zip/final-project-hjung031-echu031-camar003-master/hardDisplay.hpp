#ifndef __HARDDISPLAY_HPP__
#define __HARDDISPLAY_HPP__

#include "display.hpp"

class Hard : public Display {
    private:
	int pointsMissed;
    public:
	Hard() : Display() { pointsMissed = 0; };

	void accept(DiffSelector* visitor) {visitor->visit_hard();}
	
	virtual void draw() {
	    if (pointsMissed == 0) {
		drawEmpty();
	    }
	    else if (pointsMissed == 1) {
		drawHead();
	    }
	    else if (pointsMissed == 2) {
		drawBody();
	    }
	    else if (pointsMissed == 3) {
		drawArm();
	    }
	    else if (pointsMissed == 4) {
		drawLeg();
	    }
	}

        virtual int checkPointsMissed() { return pointsMissed; }

        virtual void updateAnswer(bool correctAnswer) {
            if (correctAnswer == true) {
                pointsMissed = pointsMissed + 0;
            }
            else {
                pointsMissed = pointsMissed + 1;
            }
        }

        void drawEmpty() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

	void drawHead() {
	    std::cout << "          |------------|       " << std::endl;
	    std::cout << "          |            |       " << std::endl;
	    std::cout << "       /)____/)        |       " << std::endl;
	    std::cout << "      ( • ㅅ• )        |       " << std::endl;
	    std::cout << "      	         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "               ________|____   " << std::endl;
	}

	void drawBody() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
	    std::cout << "       |     |         |       " << std::endl;
	    std::cout << "       |     |         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
	} 

        void drawArm() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     |\        |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

        void drawLeg() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     |\        |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
            std::cout << "       | /-\ |         |       " << std::endl;
            std::cout << "       |/   \|         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;

        }

};

#endif //__EASYDISPLAY_HPP__
