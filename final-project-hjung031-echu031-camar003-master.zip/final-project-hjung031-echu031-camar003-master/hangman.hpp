#ifndef __HANGMAN_HPP__
#define __HANGMAN_HPP__

#include "mediumDisplay.hpp"
#include "easyDisplay.hpp"
#include "hardDisplay.hpp"
#include "scoreboard.hpp"
#include "diffSelector.hpp"
#include "category.hpp"
#include "csprofscat.hpp"
#include "cskeyscat.hpp"
#include "ucrbuildscat.hpp"
#include "ucrmajscat.hpp"
#include "foodcat.hpp"
#include "scoreboard.hpp"
#include "randomcat.hpp"

#include <iostream>
#include <string>
#include <vector>

using namespace std;


class Hangman {
        public:
                Hangman() { };

                ~Hangman();
                void display();
                void print_used();
		void set_difficulty(string dif);
		bool check_answer(char gues);
		bool guesswhole();
		void traverse(char guess);
		bool redundant(char gues);
		void run();
		void set_category(string cat);
        private:
		string word;
		string current_word;
        //        string dummy;
                string difficulty;
                vector<char> usedLetters;
		bool correct;	
		bool ngameover;
		Display* man;
		scoreboard* score;
};

void Hangman::set_category(string cat){
	if(cat == "CsProfsCat"){
		ChooseCat* cat1 = new CsProfsCat();
		Category* cat2 = new Category(cat1);
		cat2->categoryword();
		word = cat2->getWord();
	}	
	else if(cat == "CsKeysCat"){
		ChooseCat* cat1 = new CsKeysCat();
		Category* cat2 = new Category(cat1);
                cat2->categoryword();
                word = cat2->getWord();

	}	
	else if(cat == "UCRBuildsCat"){
		ChooseCat* cat1 = new UCRBuildsCat();
		Category* cat2 = new Category(cat1);
                cat2->categoryword();
                word = cat2->getWord();

	}
	else if(cat == "UCRMajsCat"){
		ChooseCat* cat1 = new UCRMajsCat();
		Category* cat2 = new Category(cat1);
                cat2->categoryword();
                word = cat2->getWord();

	}		
	else if(cat == "FoodCat"){
		ChooseCat* cat1 = new FoodCat();
		Category* cat2 = new Category(cat1);
                cat2->categoryword();
                word = cat2->getWord();

	}	
	else if(cat == "RandomCat"){
		ChooseCat* cat1 = new RandomCat();
		Category* cat2 = new Category(cat1);
                cat2->categoryword();
                word = cat2->getWord();

	}
	int nsize = word.size();
	for(int i = 0; i < nsize; ++i){
		current_word += "_";
	}
}

void Hangman::set_difficulty(string dif) {
	difficulty = dif;
}

void Hangman::display() {
        if (difficulty == "1"){
	    man = new Easy();	
	    score = new scoreboard();
	}
	else if (difficulty == "2") {
	    man = new Medium();
            score = new scoreboard();
	}
	else if (difficulty == "3") {
	    man = new Hard();
            score = new scoreboard();
	}
	else {
            man = new Medium();
            score = new scoreboard();
	}
}


void Hangman::print_used() {
	cout << "Used Letters: ";
        for(int i = 0; i < usedLetters.size(); i++) {
                cout << usedLetters.at(i) << " ";
        }
	cout << endl;
}

void Hangman::traverse(char guess){
	for(int i = 0; i < current_word.size(); ++i){
		if(word.at(i) == guess){
			current_word.at(i) = guess;
			//cout << "Traverse "<< current_word << endl;
		}
	}
}

bool Hangman::check_answer(char gues) {
	correct = false;
	for(int i = 0; i < word.size();i++) {
		if(word.at(i) == gues) {
			correct = true;
		}
	}
}

bool Hangman::redundant(char gues){
	for(int i=0; i < usedLetters.size(); ++i){
		if(gues == usedLetters.at(i)){
			cout << "Letter already used. Make another guess" << endl;
			return true;
		}
	}
	return false;
}

bool Hangman::guesswhole(){
	if(word.compare(current_word) == 0){
		return false;
	}
	else{ return true;}
}


void Hangman::run() {
	display();
	bool ngameover = true;
	char gue;
	cout << "Enter letter" << endl;
	cin >> gue; 
	//cout << word << endl;
	gue = toupper(gue);
        check_answer(gue);
	if(correct){ traverse(gue);} //current word should update
	usedLetters.push_back(gue);
        man->updateAnswer(correct);
        score->calculateScore(true, correct);
        cout << "SCORE:" << score->displayCurrentScore() << endl;
        man->draw();
        cout << endl;
        cout << "             " <<current_word << endl;
	print_used();
        correct = false;

	while(ngameover) {
            do{ cin >> gue;
		gue = toupper(gue);
	    }while(redundant(gue));
            check_answer(gue);
	    if(correct){traverse(gue);} //update current_word if true
	    usedLetters.push_back(gue);
            man->updateAnswer(correct);
  	    
	    ngameover = guesswhole(); //check to see if whole word has been correctly guessed
	    score->calculateScore(false, correct);
	    cout << "SCORE:" << score->displayCurrentScore() << endl;
            man->draw();
	    cout << endl;
	    cout <<"             "<< current_word << endl;
 	    print_used();
            correct = false;	
	    if((difficulty == "1") && (man->checkPointsMissed() == 8)) {
		ngameover = false;
		cout << "You Lose!" << endl;
	    	return;
		}
	    else if((difficulty == "2") && (man->checkPointsMissed() == 6)) {
		ngameover == false;
		cout << "You Lose!" << endl;
	    	return;
		}
	    else if((difficulty == "3") &&( man->checkPointsMissed() == 4)) {
		ngameover == false;
		cout << "You Lose!" << endl;
	    	return;
		}
	}
	cout << "YOU WON!" << endl;
	return;	
}

#endif
