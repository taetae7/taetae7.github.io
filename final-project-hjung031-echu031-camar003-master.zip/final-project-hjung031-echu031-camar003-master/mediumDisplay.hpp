#ifndef __MEDIUMDISPLAY_HPP__
#define __MEDIUMDISPLAY_HPP__

#include <iostream>
#include "display.hpp"

class Medium : public Display {
    private:
	int pointsMissed;
    public:
	Medium() : Display() { pointsMissed = 0; };

	void accept(DiffSelector* visitor) {visitor->visit_medium();}

	virtual void draw() {
	    if (pointsMissed == 0) {
		drawEmpty();
	    }
	    else if (pointsMissed == 1) {
		drawHead();
	    }
	    else if (pointsMissed == 2) {
		drawBody();
	    }
	    else if (pointsMissed == 3) {
		drawArm1();
	    }
	    else if (pointsMissed == 4) {
		drawArm2();
	    }
	    else if (pointsMissed == 5) {
		drawLeg1();
	    }
	    else if (pointsMissed == 6) {
		drawLeg2();
	    }
	}

        virtual int checkPointsMissed() { return pointsMissed; }

        virtual void updateAnswer(bool correctAnswer) {
            if (correctAnswer == true) {
                pointsMissed = pointsMissed + 0;
            }
            else {
                pointsMissed = pointsMissed + 1;
            }
        }
	
	void drawEmpty() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

	void drawHead() {
	    std::cout << "          |------------|       " << std::endl;
	    std::cout << "          |            |       " << std::endl;
	    std::cout << "       /)____/)        |       " << std::endl;
	    std::cout << "      ( • ㅅ• )        |       " << std::endl;
	    std::cout << "      	         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "               ________|____   " << std::endl;
	}

	void drawBody() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
	    std::cout << "       |     |         |       " << std::endl;
	    std::cout << "       |     |         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
	} 

	void drawArm1() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     |         |       " << std::endl;
            std::cout << "      U|     |         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

        void drawArm2() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     ||        |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

        void drawLeg1() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     ||         |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
	    std::cout << "       | /             |       " << std::endl;
	    std::cout << "       |/              |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

        void drawLeg2() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     ||        |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
            std::cout << "       | /-| |         |       " << std::endl;
            std::cout << "       |/   ||         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

};

#endif //__MEDIUMDISPLAY_HPP__
