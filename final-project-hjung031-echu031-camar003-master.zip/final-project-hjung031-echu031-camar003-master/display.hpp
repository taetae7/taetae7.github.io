#ifndef __DISPLAY_HPP__
#define __DISPLAY_HPP__

#include <string>
#include "diffSelector.hpp"
//#include "hangman.hpp"


class Display {
    public:
	Display() { };

	virtual int checkPointsMissed() = 0;
	virtual void updateAnswer(bool correctAnswer) = 0;
        virtual void draw() = 0;
	virtual void accept(DiffSelector*) = 0;
};

#endif //__DISPLAY_HPP__
