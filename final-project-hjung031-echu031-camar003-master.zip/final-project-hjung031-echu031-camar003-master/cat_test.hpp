#ifndef __CAT_TEST_HPP__
#define __CAT_TEST_HPP__

#include "gtest/gtest.h"
#include "category.hpp"
#include "choosecat.hpp"
#include "randomcat.hpp"
#include "csprofscat.hpp"
#include "cskeyscat.hpp"
#include "ucrbuildscat.hpp"
#include "ucrmajscat.hpp"
#include "foodcat.hpp"
#include <iostream>
#include <string>

TEST(InitializeTest, foodtest){
	ChooseCat* foruse = new FoodCat();
	Category* cat1 = new Category(foruse);
	string str1;
	cat1->categoryword();
	EXPECT_NE(cat1->getWord(), str1);
}

TEST(InitializeTest, failtest){
        ChooseCat* foruse = new FoodCat();
        Category* cat1 = new Category(foruse);
        string str1;
        cat1->categoryword();
        EXPECT_EQ(cat1->getWord(), str1);
}


TEST(InitializeTest, fail2test){
	ChooseCat* ch1 = new UCRBuildsCat();
	Category* cat3 = new Category(ch1);
	string st3;
	cat3->categoryword();
	EXPECT_EQ(cat3->getWord(),st3);
}


#endif
