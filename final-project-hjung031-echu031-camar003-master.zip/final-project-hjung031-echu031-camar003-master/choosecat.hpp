#ifndef __CHOOSECAT_HPP__
#define __CHOOSECAT_HPP__

#include <iostream>
#include <string>
#include "category.hpp"

class Category;

class ChooseCat {
	public:
		//Constructor
		ChooseCat() {};
		
		//Pure virtual function
		virtual std::string chooseword() = 0;
};

#endif
