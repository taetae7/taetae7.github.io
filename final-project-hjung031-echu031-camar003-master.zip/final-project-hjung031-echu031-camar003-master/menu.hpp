#ifndef __menu_hpp__
#define __menu_hpp__

#include <iostream>

using namespace std;

//going to include a lot of methods to call on in options
//going to code this as a main for now
//
class menu {

	public:

	void print_menu(){
	cout << "Start Game (S)" << endl;
	cout << "Options (O)" << endl;
	cout << "Exit (E)" << endl; 
	return;
	}
	
	void print_options(){
		cout << "Choose Categories (C)" << endl;
		cout << "Choose Difficulties (D)" << endl;
		cout << "Check your best score (S)" << endl;
		cout << "Return to the menu (E)" << endl;
		return;
	}
	void print_categories(){
		cout << "Choose a category:" << endl;
		cout << "CS Professors (1)" << endl;
		cout << "CS Keywords (2)" << endl;
		cout << "UCR Buildings (3)" << endl;
		cout << "UCR Majors (4)" << endl;
		cout << "Food (5)" << endl;
		return;
	}
	void print_difficulty(){
		cout << "Choose difficulty:" << endl;
		cout << "Easy (1)" << endl;
		cout << "Medium (2)" << endl;
		cout << "Hard (3)" << endl;
		return;
	}
};
#endif
