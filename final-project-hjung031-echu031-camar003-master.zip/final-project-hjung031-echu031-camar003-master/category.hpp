#ifndef __CATEGORY_HPP__
#define __CATEGORY_HPP__

#include <iostream>
#include <string>
#include "choosecat.hpp"

class ChooseCat;


class Category {
	public:
		Category(ChooseCat* categoryname) : catname(categoryname) {}; 
		Category() : catname(nullptr) {};
		
		void categoryword() {wordforhangman = catname->chooseword();} //gets word for hangman
		std::string getWord() {return wordforhangman;} 
	protected:
		ChooseCat* catname;
		std::string wordforhangman;
};
#endif
