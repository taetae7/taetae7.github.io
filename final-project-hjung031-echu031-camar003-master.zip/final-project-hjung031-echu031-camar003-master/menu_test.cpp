#include "menu.hpp"
#include "hangman.hpp"
#include "category.hpp"
#include "choosecat.hpp"
#include "randomcat.hpp"
#include "csprofscat.hpp"
#include "cskeyscat.hpp"
#include "ucrbuildscat.hpp"
#include "ucrmajscat.hpp"
#include "foodcat.hpp"
#include "scoreboard.hpp"

#include <iostream>
#include <string>

using namespace std;

int main() {
	string receiver = "";
	string option = "";
	string gamecategory = " ";
	string gamedifficulty = " ";
	string usercategory = "";
	string userdif = "";
	
	menu test;
	
	cout << endl <<  "Welcome to Hangman! To continue select an option." << endl;
	do{	
		test.print_menu();
		cin >> receiver;
		if( receiver == "s" || receiver == "S") {
			if(gamecategory == " "){ gamecategory = "RandomCat";} //default
			if(gamedifficulty == " "){ gamedifficulty = "2";} //default
			
			Hangman* hangman1 = new Hangman(); //create hangman object
			hangman1->set_category(gamecategory); //setcategory
			hangman1->set_difficulty(gamedifficulty); //set difficulty
			//hangman1->display(); 
			hangman1->run(); //run hangman game
		}
		else if( receiver == "O" || receiver == "o" ) {
			receiver = "";
			do{
				cout << endl;
				cout << "Options Menu:" << endl;
				test.print_options();
				cin >> option;
				if (option == "E" || option == "e") {
					cout << "Exiting options and returning to menu" << endl << endl;
					break;
				}
				else if (option == "C" || option == "c") {
					do{
						test.print_categories();
						cin >> usercategory;
						if(usercategory == "1"){
							gamecategory = "CsProfsCat";
							usercategory = "e";
						}
						else if(usercategory == "2"){
							gamecategory = "CsKeysCat";
							usercategory = "e";
						}
						else if(usercategory == "3"){
							gamecategory = "UCRBuildsCat";
							usercategory = "e";
						}
						else if(usercategory == "4"){
							gamecategory = "UCRMajsCat";
							usercategory = "e";
						}
						else if(usercategory == "5"){
							gamecategory = "FoodCat";
							usercategory = "e";
						}
					}while(usercategory!= "e");
				}
				else if (option == "D" || option == "d") {
					do{
						test.print_difficulty();
						cin >> userdif;
						if(userdif == "1"){
							gamedifficulty = "1";
							userdif = "e";
						}
						else if(userdif == "2"){
							gamedifficulty = "2";
							userdif = "e";
						}
						else if(userdif == "3"){
							gamedifficulty = "3";
							userdif = "e";
						}
					}while(userdif != "e");
					
				}
				else if (option == "S" || option == "s") {
					cout << "This option will display the current best score from the play session" << endl; //still needs to be implemented
				}
				else {
					cout << "Unrecognized input. Please try again" << endl;	
				}

			}while(option != "e" && option != "E");
			if(gamecategory == " "){ gamecategory = "RandomCat";}
			if(gamedifficulty == " "){ gamedifficulty = "2";}
		}	
		else if ( receiver == "E" || receiver == "e" ) { // ask about or and and here made a mistake
			cout << endl << "Thanks for playing Hangman!" << endl;
			return 0;
		}
		else {
			cout << endl << "Sorry an unrecognized letter was received. Please look at the available options and try again" << endl << endl;
		}
	}while(receiver != "e" && receiver != "E");

	cout << "Starting game: Category: " << gamecategory << " , Difficulty: " << gamedifficulty << endl; 
	return 0;
} //end of main
