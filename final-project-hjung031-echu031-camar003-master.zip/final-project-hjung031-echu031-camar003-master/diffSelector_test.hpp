#ifndef __DIFFSELECTOR_TEST_HPP__
#define __DIFFSELECTOR_TEST_HPP__

#include "diffSelector.hpp"
#include "display.hpp"
#include "easyDisplay.hpp"
#include "mediumDisplay.hpp"
#include "hardDisplay.hpp"

#include "gtest/gtest.h"

TEST(VisitorPattern, EasyMode) {

    DiffSelector* visit = new DiffSelector();
    Display* test = new Easy();
    test->accept(visit);

    EXPECT_EQ(visit->isEasy(), true);
}

TEST(VisitorPattern2, MediumMode) {

    DiffSelector* visit = new DiffSelector();
    Display* test = new Medium();
    test->accept(visit);

    EXPECT_EQ(visit->isMedium(), true);
}

TEST(VisitorPattern3, HardMode) {

    DiffSelector* visit = new DiffSelector();
    Display* test = new Hard();
    test->accept(visit);

    EXPECT_EQ(visit->isHard(), true);
}


#endif //__DIFFSELECTOR_TEST_HPP__

