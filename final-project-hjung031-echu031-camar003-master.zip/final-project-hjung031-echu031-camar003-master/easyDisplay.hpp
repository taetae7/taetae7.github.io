#ifndef __EASYDISPLAY_HPP__
#define __EASYDISPLAY_HPP__

//#include "hangman.cpp"
#include "display.hpp"

class Easy : public Display {
    private:
	int pointsMissed;
    public:
	Easy() : Display() { pointsMissed = 0; };

	void accept(DiffSelector* visitor) {visitor->visit_easy();}

	virtual void draw() {
	    if (pointsMissed == 0) {
		drawEmpty();
	    }
	    else if (pointsMissed == 1) {
		drawHead();
	    }
	    else if (pointsMissed == 2) {
		drawEar1();
	    }
	    else if (pointsMissed == 3) {
		drawEar2();
	    }
	    else if (pointsMissed == 4) {
		drawBody();
	    }
	    else if (pointsMissed == 5) {
		drawArm1();
	    }
	    else if (pointsMissed == 6) {
		drawArm2();
	    }
            else if (pointsMissed == 7) {
                drawLeg1();
            }
            else if (pointsMissed == 8) {
                drawLeg2();
            }
	}
	
	virtual int checkPointsMissed() { return pointsMissed; }

	virtual void updateAnswer(bool correctAnswer) {
            if (correctAnswer == true) {
                pointsMissed = pointsMissed + 0;
            }
            else {
                pointsMissed = pointsMissed + 1;
            }
        }

        void drawEmpty() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

	void drawHead() {
	    std::cout << "          |------------|       " << std::endl;
	    std::cout << "          |            |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "      ( • ㅅ• )        |       " << std::endl;
	    std::cout << "      	         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
	    std::cout << "               ________|____   " << std::endl;
	}

        void drawEar1() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)__            |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

        void drawEar2() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }

	void drawBody() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
	    std::cout << "       |     |         |       " << std::endl;
	    std::cout << "       |     |         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
	} 

	void drawArm1() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     |         |       " << std::endl;
            std::cout << "      U|     |         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }
        void drawArm2() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     |\        |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;
        }
	void drawLeg1() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     |\        |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
	    std::cout << "       | /             |       " << std::endl;
	    std::cout << "       |/              |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;

        }
        void drawLeg2() {
            std::cout << "          |------------|       " << std::endl;
            std::cout << "          |            |       " << std::endl;
            std::cout << "       /)____/)        |       " << std::endl;
            std::cout << "      ( • ㅅ• )        |       " << std::endl;
            std::cout << "      /|     |\        |       " << std::endl;
            std::cout << "      U|     |U        |       " << std::endl;
            std::cout << "       | /-\ |         |       " << std::endl;	
            std::cout << "       |/   \|         |       " << std::endl;
	    std::cout << "                       |       " << std::endl;
            std::cout << "               ________|____   " << std::endl;

        }

};

#endif //__EASYDISPLAY_HPP__

