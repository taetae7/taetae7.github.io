#ifndef __UCRMAJSCAT_HPP__
#define __UCRMAJSCAT_HPP__

#include "choosecat.hpp"
#include <iostream>
#include <fstream> //outfile
#include <stdlib.h> //srand, rand
#include <time.h> //time

using namespace std;

class UCRMajsCat: public ChooseCat{
        public:
                UCRMajsCat() {};
                string chooseword();
};

string UCRMajsCat::chooseword(){
        int iLine = 0;
        srand (time(NULL)); //initialize random seed
        iLine = rand() % 21 + 1; // generate random number from 1 to 21
        string dummy; //to put words we dont use
        string chosenword; //word we do use


        ifstream ifs;
        ifs.open("ucrmajors.txt"); //open txt file
        if(ifs.is_open()){ //check to see if file opened properly
                for(int i = 0; i < iLine; ++i){
                        if(i == (iLine-1)){ // rand number
                                getline(ifs, chosenword);
                        }
                        else{
                                getline(ifs, dummy);
                        }
                }
        }
        else{ //txt file didnt open
                cerr << "Error opening file" << endl;
                return nullptr;
        }

        ifs.close(); //close txt file
        return chosenword;
} //end of f(x)


#endif
