#ifndef __SCOREBOARD_HPP__
#define __SCOREBOARD_HPP__

//#include "hangman.hpp"

class scoreboard {
    private:
	int currentScore;
	int bestScore;
    public:
	scoreboard() { };
 	scoreboard(int currentScore) { this->currentScore = currentScore; }
	void calculateScore(bool begin, bool correctLetter){

	    if (begin == true && correctLetter == true) {
		bestScore = 0;
		currentScore = 10;
	    }
	    else if (begin == true && correctLetter == false) {
		bestScore = 0;
		currentScore = 0;
	    }
	    else if (begin == false && correctLetter == true){
		currentScore = currentScore + 10;
	    }
	    else if (begin == false && correctLetter == false) {
	    	currentScore = currentScore + 0;
	    }

	    if (currentScore > bestScore) {
                bestScore = currentScore;
            }	
	}
	int displayBestScore() { return bestScore; }
	int displayCurrentScore() { return currentScore; }
};

#endif //__SCOREBOARD_HPP__
