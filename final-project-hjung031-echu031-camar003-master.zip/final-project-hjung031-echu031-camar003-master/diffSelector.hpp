#ifndef __DIFFSELECTOR_HPP__
#define __DIFFSELECTOR_HPP__

class DiffSelector {
    private:
	bool easyMode = false;
	bool mediumMode = false;
	bool hardMode = false;
    public:
	DiffSelector() { }

	void visit_easy(){easyMode = true;}
	bool isEasy(){return easyMode;}
	void visit_medium(){mediumMode = true;}
	bool isMedium(){return mediumMode;}
	void visit_hard(){hardMode = true;}
	bool isHard(){return hardMode;}

};

#endif //__DIFFSELECTOR_HPP__
