 > As you complete each section you **must** remove the prompt text. Every *turnin* of this project includes points for formatting of this README so keep it clean and keep it up to date. 
 > Prompt text is any lines beginning with "\<"
 > Replace anything between \<...\> with your project specifics and remove angle brackets. For example, you need to name your project and replace the header right below this line with that title (no angle brackets). 
# Advanced Hangman
 > Your author list below should include links to all members GitHub and should begin with a "\<" (remove existing author).
 
 > Authors: \<[Crimson Amaro](https://github.com/camaro003), [Paul Hyuntae Jung](https://github.com/hjung031), [Eric Chu](https://github.com/echu031)\>
 
 > You will be forming a group of **THREE** students and work on an interesting project that you will propose yourself (in this `README.md` document). You can pick any project that you'd like, but it needs ot implement three design patterns. Each of the members in a group is expected to work on at least one design pattern and its test cases. You can, of course, help each other, but it needs to be clear who will be responsible for which pattern and for which general project features.
 
 > ## Expectations
 > * Incorporate **three** distinct design patterns, *two* of the design patterns need to be taught in this course:
 >   * Composite, Strategy, Abstract Factory, Visitor
 > * All three design patterns need to be linked together (it can't be three distinct projects)
 > * Your project should be implemented in C/C++. If you wish to choose anoher programming language (e.g. Java, Python), please discuss with your lab TA to obtain permission.
 > * You can incorporate additional technologies/tools but they must be approved (in writing) by the instructor or the TA.
 > * Each member of the group **must** be committing code regularly and make sure their code is correctly attributed to them. We will be checking attributions to determine if there was equal contribution to the project.

## Project Description
 > Your project description should summarize the project you are proposing. Be sure to include
 > * Why is it important or interesting to you?
 >   * Hangman is a well known, straightforward game that many understand without rules. It can easily be implemented with C++ without the help of other external programs. It can also be modified enough to make each game unique and interesting. Our group wanted to create a puzzle game purely from C++ that the players can enjoy and be amazed by how a game can even be played on the terminal. Despite not being a professional, high graphic game, this project will allow us to collaborate (one of the most important skills) with team members and experience how a game or program might be created in real scenarios such as utilizing github and design patterns.
 > * What languages/tools/technologies do you plan to use? (This list may change over the course of the project)
 >   * We will be programming in C++, and using github and putty.
 > * What will be the input/output of your project?
 >   * The user will be shown a menu where they have to input S - to start game, O - to open options, or E - to exit application. If they type S, they will start the game with a random category and medium difficulty. If they type O, the options menu will be shown and they can choose their categories and difficulty. When the game is in progress the user can input a letter (to determine the word) and the output shown will be the displayed hangman, the current word progress, the current score, and the letters used. When the game has ended it will display the best score.
 > * What are the three design patterns you will be using. For each design pattern you must:
 >   * Our group will utilize Strategy, Decorator, and Visitor as the three main design patterns. The *strategy design pattern* (common for games), allows you to change the algorithm we are using in the program. Lets say, coding the scoring. Each one of us can have a different option. It's not going to have the same scoring pattern each time. The score is expected to change dynamically with the program. We will also use the *decorator design pattern* for updating the screen. The game display will need to change everytime a new letter is inputted by the user. The decorator design pattern will be able to manage the current hangman, the current score, current word progress, and current letters used. The screen will also update when the game ends. Lastly, we will be using the *visitor design pattern* for the default game option. This is when the user starts the game without previously picking a specific category or difficulty level. Therefore, the visitor design pattern will be able to reach the category class and the difficulty class. The category used will be random and the difficulty will be set to medium.

 > ## Phase II
 > In addition to completing the "Class Diagram" section below, you will need to 
 > * Set up your GitHub project board as a Kanban board for the project. It should have columns that map roughly to 
 >   * Backlog, TODO, In progress, In testing, Done
 >   * You can change these or add more if you'd like, but we should be able to identify at least these.
 > * There is no requirement for automation in the project board but feel free to explore those options.
 > * Create an "Epic" (note) for each feature and each design pattern and assign them to the appropriate team member. Place these in the `Backlog` column
 > * Complete your first *sprint planning* meeting to plan out the next 7 days of work.
 >   * Create smaller development tasks as issues and assign them to team members. Place these in the `Backlog` column.
 >   * These cards should represent roughly 7 days worth of development time for your team, taking you until your first meeting with the TA
## Class Diagram
 > * The pdf for this is uploaded under "CS100 Phase II - Design Document"
 > * Include a class diagram(s) for each design pattern and a description of the diagram(s). This should be in sufficient detail that another group could pick up the project this point and successfully complete it. Use proper OMT notation (as discussed in the course slides). You may combine multiple design patterns into one diagram if you'd like, but it needs to be clear which portion of the diagram represents which design pattern (either in the diagram or in the description).
 
 > ## Phase III
 > You will need to schedule a check-in with the TA (during lab hours or office hours). Your entire team must be present. 
 > * Before the meeting you should perform a sprint plan like you did in Phase II
 > * In the meeting with your TA you will discuss: 
 >   - How effective your last sprint was (each member should talk about what they did)
 >   - Any tasks that did not get completed last sprint, and how you took them into consideration for this sprint
 >   - Any bugs you've identified and created issues for during the sprint. Do you plan on fixing them in the next sprint or are they lower priority?
 >   - What tasks you are planning for this next sprint.

 > ## Final deliverable
 > All group members will give a demo to the TA during lab time. The TA will check the demo and the project GitHub repository and ask a few questions to all the team members. 
 > Before the demo, you should do the following:
 > * Complete the sections below (i.e. Screenshots, Installation/Usage, Testing)
 > * Plan one more sprint (that you will not necessarily complete before the end of the quarter). Your In-progress and In-testing columns should be empty (you are not doing more work currently) but your TODO column should have a full sprint plan in it as you have done before. This should include any known bugs (there should be some) or new features you would like to add. These should appear as issues/cards on your Kanban board. 
 ## Screenshots
 > Please see above screenshots in the files section at the top.
 ## Installation/Usage
 > Instructions:
> Our program runs on any linux interface.
> Run cmake3 . , make , ./game to begin the game
> 
> You will be prompted to 
> 1. Start game (S), 2. Go to Options (O), 3. Exit (E).
> 
> If you choose the options menu, you will be prompted to 
> 1. Choose category of the word, 2. Choose your difficulty level, 3. Exit to main menu.
> 
> The only way to start the game after you are in the options menu is to exit back to main menu and choose Start game. 
> 
> When you start the game, it will load with a random word from the category you picked. If you don't choose a category it will run with a random word from any category. If you > did not choose a difficulty level, it will run on it’s default level (medium).
> 
> You will pick a letter until you solve the word or run out of tries (the hangman’s body is fully displayed).
> 
> After the game is over you will be sent back to the main menu where you can choose to play again with the same settings, choose different settings, or exit.

 ## Testing
 > Testing:
> 
> Our program was tested using google unit testing. We set up unit tests along the way to make sure that the programs and classes were working properly before merging it all together. After merging we ran more tests where we ran into errors. We also did testing straight out of the console by running our programs and selecting random values. We ran into segmentation faults where we had to trace the code line by line and place cout statements to locate the error.

 
