#include "gtest/gtest.h"

#include "scoreboard_test.hpp"
#include "display_test.hpp"
#include "diffSelector_test.hpp"
#include "cat_test.hpp"

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
